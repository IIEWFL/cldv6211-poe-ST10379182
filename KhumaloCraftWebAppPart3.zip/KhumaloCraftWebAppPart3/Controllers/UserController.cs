﻿using KhumaloCraftWebAppPart2.Data;
using Microsoft.AspNetCore.Mvc;
using KhumaloCraftWebAppPart2.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Diagnostics;
using System.Threading.Tasks;


namespace KhumaloCraftWebAppPart2.Controllers
{
    public class UserController : Controller
    {
        private readonly ApplicationDbcontext _context;

        public UserController(ApplicationDbcontext context)
        {
            _context = context;
        }

        // Action to display list of users
        public IActionResult Index()
        {
            var users = _context.UserAccountAdd.ToList();
            return View(users);
        }

        // Action to display form for creating a new user
        public IActionResult Create()
        {
            return View();
        }

        // Action to handle POST request for creating a new user
        [HttpPost]
        public IActionResult Create(UserAccountAdd user)
        {
            if (ModelState.IsValid)
            {
                _context.UserAccountAdd.Add(user);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(user);
        }

        // Actions for updating and deleting users
    }
}