﻿using KhumaloCraftWebAppPart2.Data;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace KhumaloCraftWebAppPart2.Controllers
{
    public class MyWorkController : Controller
    {
        private readonly ApplicationDbcontext _context;

        public MyWorkController(ApplicationDbcontext context)
        {
            _context = context;
        }


    }
}
