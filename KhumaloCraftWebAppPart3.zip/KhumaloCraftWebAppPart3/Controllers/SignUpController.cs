﻿

using System.Data;
using System.Data.SqlClient;
using KhumaloCraftWebAppPart2.Models;
using Microsoft.AspNetCore.Mvc;


public class SignUpController : Controller
{
    private readonly IConfiguration _configuration;

    public SignUpController(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    [HttpPost]
    public IActionResult SignUp(UserAccountAdd user)
    {
        string connectionString = _configuration.GetConnectionString("DefaultConnection");

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string sql = @"INSERT INTO dbo.UserAccountAdd (Username, Password, Email, FirstName, LastName)
                           VALUES (@Username, @Password, @Email, @FirstName, @LastName)";

            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                command.Parameters.AddWithValue("@Username", user.Username);
                command.Parameters.AddWithValue("@Password", user.Password);
                command.Parameters.AddWithValue("@Email", user.Email);
                command.Parameters.AddWithValue("@FirstName", user.FirstName);
                command.Parameters.AddWithValue("@LastName", user.LastName);

                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
        }

        return RedirectToAction("SignUpSuccess");
    }

    public IActionResult SignUpSuccess()
    {
        return View();
    }
}
