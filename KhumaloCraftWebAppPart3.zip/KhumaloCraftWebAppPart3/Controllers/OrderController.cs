﻿//using KhumaloCraftWebAppPart2.Data;
//using KhumaloCraftWebAppPart2.Models;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;

//namespace KhumaloCraftWebAppPart2.Controllers
//{
//    public class OrderController : Controller
//    {
//        private readonly ApplicationDbContext _context;

//        public OrderController(ApplicationDbContext context)
//        {
//            _context = context;
//        }

        // Action to display form for placing an order
       



        //// Action to display list of previous orders for a user
        //public IActionResult MyOrders(int userId)
        //{
        //    var orders = _context.Orders.Where(o => o.UserAccountAddId == userId).ToList();
        //    return View(orders);
        //}

    //    [HttpPost]
    //    public IActionResult PlaceOrder(Order order)
    //    {
    //        if (ModelState.IsValid)
    //        {
    //            // Update product availability
    //            var product = _context.Products.FirstOrDefault(p => p.ProductId == order.ProductId);
    //            if (product != null)
    //            {
    //                product.Availability = false;
    //                _context.SaveChanges();
    //            }

    //            // Save order details
    //            _context.Orders.Add(order);
    //            _context.SaveChanges();

    //            return RedirectToAction("Index", "Home"); // Redirect to home page or order confirmation page
    //        }
    //        return View(order);
    //    }
    //}

