﻿using System.ComponentModel.DataAnnotations;

namespace KhumaloCraftWebAppPart2.Models
{
    public class Products
    {
        [Key] // This defines ProductId as the primary key
        public int ProductId { get; set; }

        [Required] // This ensures that ProductName is required
        public required string ProductName { get; set; } // Changed to string

        [Required] // This ensures that ArtistName is required
        public required string ArtistName { get; set; }

        [Required] // This ensures that Price is required
        public decimal Price { get; set; }

        [Required] // This ensures that Description is required
        public required string Description { get; set; } // Changed to string

        [Required] // This ensures that Category is required
        public required string Category { get; set; }

        [Required] // This ensures that Availability is required
        public bool Availability { get; set; }
    }
}


