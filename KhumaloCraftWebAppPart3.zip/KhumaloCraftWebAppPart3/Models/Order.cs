﻿namespace KhumaloCraftWebAppPart2.Models
{
    public class Order
    {
        public int OrderId { get; set; }
        public int UserAccountAddId { get; set; }
        public int ProductId { get; set; }
        public DateTime OrderDate { get; set; }
        // Add other properties such as quantity, status, etc. as needed
    }
}