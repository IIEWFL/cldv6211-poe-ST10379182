﻿//UserAccountAddModel
using System.ComponentModel.DataAnnotations;

    namespace KhumaloCraftWebAppPart2.Models
{ 
        public class UserAccountAdd
        {
            [Key]
            public int UserId { get; set; }

            [Required(ErrorMessage = "Username is required")]
            public string? Username { get; set; }

            [Required(ErrorMessage = "Password is required")]
            [DataType(DataType.Password)]
            [MinLength(8)]
            public string? Password { get; set; }

            //[Compare("Password", ErrorMessage = "Passwords do not match")]
            //[DataType(DataType.Password)]
            //[Required(ErrorMessage = "Confirm Password is required")]
            //public string? ConfirmPassword { get; set; }

            [Required(ErrorMessage = "Email is required")]
            [EmailAddress(ErrorMessage = "Invalid email address")]
            public string? Email { get; set; }

            [Required(ErrorMessage = "First Name is required")]
            public string? FirstName { get; set; }

            [Required(ErrorMessage = "Last Name is required")]
            public string? LastName { get; set; }
        }
    }
