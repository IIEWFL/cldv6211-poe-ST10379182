﻿//ApplicationDBContext
using KhumaloCraftWebAppPart2.Models;

using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace KhumaloCraftWebAppPart2.Data
{
   
    public class ApplicationDbcontext : IdentityDbContext<IdentityUser>
    {
        public ApplicationDbcontext(DbContextOptions<ApplicationDbcontext> options)
            : base(options)
        {
        }

        public DbSet<UserAccountAdd> UserAccountAdd { get; set; }
        public DbSet<Products> Products { get; set; }
    }
}
